//
//  Tercer.swift
//  PentagooWCoreData
//
//  Created by Juan Arengo on 5/04/20.
//  Copyright © 2020 Juan Arango. All rights reserved.
//

import SwiftUI

struct Tercer: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct Tercer_Previews: PreviewProvider {
    static var previews: some View {
        Tercer()
    }
}
